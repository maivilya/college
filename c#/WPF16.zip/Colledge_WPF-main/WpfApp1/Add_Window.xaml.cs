﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class Add_Window : Window
    {
        public Add_Window()
        {
            InitializeComponent();
        }

        private void save_button_Click(object sender, RoutedEventArgs e)
        {
            DateTime a = new DateTime();
            a = Convert.ToDateTime(DateToDo.SelectedDate);

            (this.Owner as MainWindow).ListToDo.Add(new ToDo(TitleToDo.Text, a, DiscriptionToDo.Text, false));
            (this.Owner as MainWindow).LisToDo.ItemsSource = null;
            (this.Owner as MainWindow).LisToDo.ItemsSource = (this.Owner as MainWindow).ListToDo;

            TitleToDo.Text = null;
            DateToDo.SelectedDate = null;
            DiscriptionToDo.Text = null;

            this.Close();
            (this.Owner as MainWindow).EndToDo();
        }
    }
}
