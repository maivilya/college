﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace WpfApp1
{
    public class DateTimeLessConverter : IValueConverter
    {
        public object Convert(object value, Type targettype, object parametr, CultureInfo culture)
        {
            var check = value as DateTime?;
            if (check != null)
            {
                return DateTime.Now > check.Value;
            }
            return false;
        }
        public object ConvertBack(object value, Type targettype, object parametr, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class DateTimeEvenlyConverter : IValueConverter
    {
        public object Convert(object value, Type targettype, object parametr, CultureInfo culture)
        {
            var check = value as DateTime?;
            if (check != null)
            {
                return (DateTime.Now.Year == check.Value.Year && DateTime.Now.Month == check.Value.Month && (check.Value.Day == DateTime.Now.Day));
            }
            return false;
        }
        public object ConvertBack(object value, Type targettype, object parametr, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class DateTimeTomorrowConverter : IValueConverter
    {
        public object Convert(object value, Type targettype, object parametr, CultureInfo culture)
        {
            var check = value as DateTime?;
            if (check != null)
            {
                return (DateTime.Now.Year == check.Value.Year && DateTime.Now.Month == check.Value.Month && (check.Value.Day - DateTime.Now.Day) == 1);
            }
            return false;
        }
        public object ConvertBack(object value, Type targettype, object parametr, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
