﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public int count_list = 0;
        public List<ToDo> ListToDo = new List<ToDo>();
        public MainWindow()
        {
            InitializeComponent();
            ListToDo.Add(new ToDo("Убраться", new DateTime(2024, 03, 20), "Протереть полки и вымыть полы", false));
            ListToDo.Add(new ToDo("Поработать", new DateTime(2024, 01, 12), "Доделать...", false));
            ListToDo.Add(new ToDo("Приготовить поесть", new DateTime(2025, 06, 13), "Для начала сходить за продуктами, а потом приготовить поесть", false));

            EndToDo();

            LisToDo.ItemsSource = null;
            LisToDo.ItemsSource = ListToDo;
        }

        private void delete_button_Click(object sender, RoutedEventArgs e)
        {
            ListToDo.Remove((sender as Button).DataContext as ToDo);

            LisToDo.ItemsSource = null;
            LisToDo.ItemsSource = ListToDo;
            EndToDo();
        }

        private void add_button_Click(object sender, RoutedEventArgs e)
        {
            Add_Window added_window = new Add_Window();
            added_window.Owner = this;
            this.IsEnabled = false;
            added_window.Show();
            this.IsEnabled = true;
            EndToDo();
        }

        private void Cheked_Box_Checked(object sender, RoutedEventArgs e)
        {
            if ((sender as CheckBox).DataContext as ToDo != null)
            {
                ((sender as CheckBox).DataContext as ToDo).IsDone = true;
            }
            EndToDo();
        }

        private void Cheked_Box_Unchecked(object sender, RoutedEventArgs e)
        {
            if ((sender as CheckBox).DataContext as ToDo != null)
            {
                ((sender as CheckBox).DataContext as ToDo).IsDone = false;
                EndToDo();
            }
        }

        public void EndToDo()
        {
            Progress_Bar.Minimum = 0;
            Progress_Bar.Maximum = ListToDo.Count;
            Progress_Bar.Value = 0;

            for (int i = 0; i < ListToDo.Count; i++)
            {
                if (ListToDo[i].IsDone == true)
                {
                    Progress_Bar.Value += 1;
                }
            }
            Text_Progress.Text = $"{Progress_Bar.Value}/{ListToDo.Count}";
        }
    }
}
