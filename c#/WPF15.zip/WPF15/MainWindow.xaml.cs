﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr12
{
    public partial class MainWindow : Window
    {
        public static List<Todo> todoList = new List<Todo>();
        public MainWindow()
        {
            InitializeComponent();

            todoList.Add(new Todo("Приготовить покушать", new DateTime(2024, 1, 15), "Нет описания", false));
            todoList.Add(new Todo("Поработать", new DateTime(2024, 1, 20), "Съездить на совещание в Москву", false));
            todoList.Add(new Todo("Отдохнуть", new DateTime(2024, 2, 1), "Съездить в отпуск в Сочи", false));
            Progress_Bar.Minimum = 0;
            Progress_Bar.Maximum = todoList.Count;
            Progress_Bar.Value = 0;
            Text_Progress.Text = $"{Progress_Bar.Value}/{todoList.Count}";

            listToDo.ItemsSource = null;
            listToDo.ItemsSource = todoList;

        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 addWindow = new Window1();
            addWindow.Owner = this;
            this.IsEnabled = false;
            addWindow.Show();
            this.IsEnabled = true;
            EndToDo();
        }
        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            todoList.Remove(listToDo.SelectedItem as Todo);
            listToDo.ItemsSource = null;
            listToDo.ItemsSource = todoList;
            EndToDo();
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (listToDo.SelectedItem != null)
            {
                (listToDo.SelectedItem as Todo).IsDone = true;
                EndToDo();
            }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            if (listToDo.SelectedItem != null)
            {
                (listToDo.SelectedItem as Todo).IsDone = false;
                EndToDo();
            }
        }

        public void EndToDo()
        {
            Progress_Bar.Minimum = 0;
            Progress_Bar.Maximum = todoList.Count;
            Progress_Bar.Value = 0;

            for (int i = 0; i < todoList.Count; i++)
            {
                if (todoList[i].IsDone == true)
                {
                    Progress_Bar.Value += 1;
                }
            }
            Text_Progress.Text = $"{Progress_Bar.Value}/{todoList.Count}";
        }
    }
}
