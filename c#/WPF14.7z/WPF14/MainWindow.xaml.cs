﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr12
{
    public partial class MainWindow : Window
    {
        public static List<Todo> todoList = new List<Todo>();
        public MainWindow()
        {
            InitializeComponent();
            todoList.Add(new Todo("Приготовить покушать", new DateTime(2024, 1, 15), "Нет описания", false));
            todoList.Add(new Todo("Поработать", new DateTime(2024, 1, 20), "Съездить на совещание в Москву", false));
            todoList.Add(new Todo("Отдохнуть", new DateTime(2024, 2, 1), "Съездить в отпуск в Сочи", false));
            listToDo.ItemsSource = null;
            listToDo.ItemsSource = todoList;

        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 addWindow = new Window1();
            addWindow.Owner = this;
            addWindow.Show();
        }
        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            todoList.Remove(listToDo.SelectedItem as Todo);
            listToDo.ItemsSource = null;
            listToDo.ItemsSource = todoList;
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (listToDo.SelectedItem != null)
            {
                (listToDo.SelectedItem as Todo).IsDone = true;
            }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            if (listToDo.SelectedItem != null)
            {
                (listToDo.SelectedItem as Todo).IsDone = false;
            }
        }
    }
    

    
}
