﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace pr12
{
    public class Todo
    {
        

        public string Title { get; set; }
        public DateTime DueDate { get; set; }
        public string DescriptionTodo { get; set; }
        public bool IsDone { get; set; }

        public Todo(string title, DateTime date, string descriptionToDo, bool isDone)
        {
            this.Title = title;
            this.DueDate = date;
            this.DescriptionTodo = descriptionToDo;
            this.IsDone = isDone;
        }
    }
}
