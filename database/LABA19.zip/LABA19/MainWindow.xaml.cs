﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace LABA19
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //saveEditButtonView.Visibility = Visibility.Hidden;
           // cancelEditButtonView.Visibility = Visibility.Hidden;
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetPhonesList();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            AddWindow addWindow = new AddWindow();
            addWindow.Owner = this;
            addWindow.Show();
            this.IsEnabled = false;
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            Phone updatedPhone = mainDataGridView.SelectedItem as Phone;
            if (updatedPhone != null)
            {
                EditWindow editWindow = new EditWindow(updatedPhone);
                editWindow.Owner = this;
                editWindow.Show();
                this.IsEnabled = false;
            } else
            {
                errorBox.Text = "Вы не выбрали телефон для редактирования";
            }
        }

        private void EraseButton_Click(object sender, RoutedEventArgs e)
        {
            if (mainDataGridView.SelectedItem as Phone != null)
            {
                mainDataGridView.IsEnabled = false;
                addButtonView.IsEnabled = false;
                saveornotsave.Visibility = Visibility.Visible;
            }
            else
            {
                errorBox.Text = "Вы не выбрали телефон для удаления";
            }
        }

        /*private void CancelEditButton_Click(object sender, RoutedEventArgs e)
        {
            EndEditing();
        }

        private void EndEditing()
        {
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;

            mainListBox.IsEnabled = true;
            addButtonView.IsEnabled = true;
            editButtonView.IsEnabled = true;
            deleteButtonView.IsEnabled = true;

            saveEditButtonView.Visibility = Visibility.Hidden;
            cancelEditButtonView.Visibility = Visibility.Hidden;
        }*/

        private void yesButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            DatabaseControl.DeletePhone(mainDataGridView.SelectedItem as Phone);
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetPhonesList();
            errorBox.Text = String.Empty;
            mainDataGridView.IsEnabled = true;
            addButtonView.IsEnabled = true;
        }

        private void noButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            errorBox.Text = String.Empty;
            mainDataGridView.IsEnabled = true;
            addButtonView.IsEnabled = true;
        }

        /*<Grid.ColumnDefinitions>
            <ColumnDefinition />
            <ColumnDefinition />
        </Grid.ColumnDefinitions>

        <Grid.RowDefinitions>
            <RowDefinition Height = "5*" />
            < RowDefinition />
        </ Grid.RowDefinitions >

        < ListBox Grid.Column="0" Grid.Row="0" Name="mainListBox" SelectionMode="Single" Margin="10" >
            <ListBox.ItemTemplate>
                <DataTemplate>
                    <StackPanel>
                        <TextBlock FontSize = "18" Text="{Binding Path= Title}"></TextBlock>
                        <TextBlock Text = "{Binding Path=CompanyEntity.Title}" ></ TextBlock >
                        < TextBlock Text="{Binding Path=Price}"></TextBlock>
                    </StackPanel>
                </DataTemplate>
            </ListBox.ItemTemplate>
        </ListBox>

        <GroupBox Name = "mainGroupBox" Grid.Column="1" Grid.Row="0" Margin="10" >
            <StackPanel Grid.Column="1">
                <TextBlock>Выбранный элемент</TextBlock>
                <TextBlock>Модель</TextBlock>
                <TextBox Name = "titleView" ></ TextBox >
                < TextBlock > Производитель </ TextBlock >
                < ComboBox Name= "companyView" >
                    < ComboBox.ItemTemplate >
                        < DataTemplate >
                            < TextBlock Text= "{Binding Path=Title}" />
                        </ DataTemplate >
                    </ ComboBox.ItemTemplate >
                </ ComboBox >
                < TextBlock > Цена </ TextBlock >
                < TextBox Name = "priceView" ></ TextBox >
                < TextBlock Name= "errorBox" />

                < StackPanel x:Name= "saveornotsave" VerticalAlignment= "Bottom" Visibility= "Hidden" >
                    < TextBlock Name= "saveQuestion" HorizontalAlignment= "Center" Text= "Хотите сохранить изменения?" />
                    < WrapPanel HorizontalAlignment= "Center" >
                        < Button Name= "yesButton"  MinWidth= "30" MaxWidth= "50" Click= "yesButton_Click" > Да </ Button >
                        < Button Name= "noButton" MinWidth= "30" MaxWidth= "50" Click= "noButton_Click" > Нет </ Button >
                    </ WrapPanel >
                </ StackPanel >

            </ StackPanel >
        </ GroupBox >

        < StackPanel Grid.Row= "1" Grid.Column= "0" Orientation= "Horizontal" >


            < Button x:Name= "editButtonView" Click= "EditButton_Click" Background= "Transparent"
                    Grid.Row= "1" MinWidth= "50" MaxWidth= "70" Margin= "10" BorderThickness= "0" >
                < Image Source= "/Image/edit.png" />
            </ Button >

            < Button x:Name= "deleteButtonView" Click= "EraseButton_Click" Background= "Transparent"
                    Grid.Row= "1" MinWidth= "50" Margin= "10" BorderThickness= "0" >
                < Image Source= "/Image/minus.png" />
            </ Button >

        </ StackPanel >

        < StackPanel Grid.Row= "1" Grid.Column= "1" Orientation= "Horizontal" >

            < Button x:Name= "saveEditButtonView" Click= "SaveEditButton_Click" MinWidth= "50" MaxWidth= "100" Margin= "10"
                    Grid.Row= "1" Background= "Transparent" BorderThickness= "0" >
                < Image Source= "/Image/save.png" />
            </ Button >

            < Button x:Name= "cancelEditButtonView" Click= "CancelEditButton_Click" MinWidth= "50" MaxWidth= "100" Margin= "10"
                    Grid.Row= "1" Background= "Transparent" BorderThickness= "0" >
                < Image Source= "/Image/cancel.png" />
            </ Button >
        </ StackPanel >*/
    }
}
