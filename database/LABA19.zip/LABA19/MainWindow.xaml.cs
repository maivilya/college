﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace LABA19
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //saveEditButtonView.Visibility = Visibility.Hidden;
           // cancelEditButtonView.Visibility = Visibility.Hidden;
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetPhonesList();
            //companyView.ItemsSource = null;
            //companyView.ItemsSource = DatabaseControl.GetCompanyList();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            /*if (!String.IsNullOrWhiteSpace(titleView.Text) && companyView.SelectedIndex != -1 && !String.IsNullOrWhiteSpace(priceView.Text) && IsNum(priceView.Text) && Convert.ToDecimal(priceView.Text) > 0)
            {
                DatabaseControl.AddPhone(new Phone
                {
                    Title = titleView.Text,
                    CompanyId = (companyView.SelectedItem as Company).Id,
                    Price = Convert.ToDecimal(priceView.Text)
                });
                mainListBox.ItemsSource = null;
                mainListBox.ItemsSource = DatabaseControl.GetPhonesList();
                titleView.Text = String.Empty;
                companyView.Text = String.Empty;
                priceView.Text = String.Empty;
                errorBox.Text = String.Empty;
                EndEditing();
            }
            else
            {
                errorBox.Text = "Заполните данные корректно";
            }*/
            AddWindow addWindow = new AddWindow();
            addWindow.Owner = this;
            addWindow.Show();
        }

        private void SaveEditButton_Click(object sender, RoutedEventArgs e)
        {
            Phone updatedPhone = mainListBox.SelectedItem as Phone;
            if (!String.IsNullOrWhiteSpace(titleView.Text) && companyView.SelectedIndex != -1 && !String.IsNullOrWhiteSpace(priceView.Text) && IsNum(priceView.Text) && Convert.ToDecimal(priceView.Text) > 0)
            {
                updatedPhone.Title = titleView.Text;
                updatedPhone.CompanyId = (companyView.SelectedItem as Company).Id;
                updatedPhone.Price = Convert.ToDecimal(priceView.Text);
                DatabaseControl.UpdatePhone(updatedPhone);

                mainListBox.ItemsSource = null;
                mainListBox.ItemsSource = DatabaseControl.GetPhonesList();
                errorBox.Text = String.Empty;
                EndEditing();
            }
            else
            {
                errorBox.Text = "Заполните данные корректно";
            }

        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            Phone tempPhone = mainListBox.SelectedItem as Phone;
            if (tempPhone != null)
            {
                titleView.Text = tempPhone.Title;
                companyView.SelectedIndex = tempPhone.CompanyId - 1;
                priceView.Text = tempPhone.Price.ToString();

                mainListBox.IsEnabled = false;
                addButtonView.IsEnabled = false;
                editButtonView.IsEnabled = false;
                deleteButtonView.IsEnabled = false;

                saveEditButtonView.Visibility = Visibility.Visible;
                cancelEditButtonView.Visibility = Visibility.Visible;
            }
        }

        private void EraseButton_Click(object sender, RoutedEventArgs e)
        {
            if (mainListBox.SelectedItem as Phone != null)
            {
                mainListBox.IsEnabled = false;
                addButtonView.IsEnabled = false;
                editButtonView.IsEnabled = false;
                deleteButtonView.IsEnabled = false;
                saveornotsave.Visibility = Visibility.Visible;
            }
            else
            {
                errorBox.Text = "Вы не выбрали телефон для удаления";
            }
        }

        private void CancelEditButton_Click(object sender, RoutedEventArgs e)
        {
            EndEditing();
        }

        private void EndEditing()
        {
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;

            mainListBox.IsEnabled = true;
            addButtonView.IsEnabled = true;
            editButtonView.IsEnabled = true;
            deleteButtonView.IsEnabled = true;

            saveEditButtonView.Visibility = Visibility.Hidden;
            cancelEditButtonView.Visibility = Visibility.Hidden;
        }

        private void yesButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            DatabaseControl.DeletePhone(mainListBox.SelectedItem as Phone);
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = DatabaseControl.GetPhonesList();
            errorBox.Text = String.Empty;
            EndEditing();
        }

        private void noButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            EndEditing();
        }

        private bool IsNum(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsDigit(c)) return false;
            }
            return true;
        }

        /*<Grid.ColumnDefinitions>
            <ColumnDefinition />
            <ColumnDefinition />
        </Grid.ColumnDefinitions>

        <Grid.RowDefinitions>
            <RowDefinition Height = "5*" />
            < RowDefinition />
        </ Grid.RowDefinitions >

        < ListBox Grid.Column="0" Grid.Row="0" Name="mainListBox" SelectionMode="Single" Margin="10" >
            <ListBox.ItemTemplate>
                <DataTemplate>
                    <StackPanel>
                        <TextBlock FontSize = "18" Text="{Binding Path= Title}"></TextBlock>
                        <TextBlock Text = "{Binding Path=CompanyEntity.Title}" ></ TextBlock >
                        < TextBlock Text="{Binding Path=Price}"></TextBlock>
                    </StackPanel>
                </DataTemplate>
            </ListBox.ItemTemplate>
        </ListBox>

        <GroupBox Name = "mainGroupBox" Grid.Column="1" Grid.Row="0" Margin="10" >
            <StackPanel Grid.Column="1">
                <TextBlock>Выбранный элемент</TextBlock>
                <TextBlock>Модель</TextBlock>
                <TextBox Name = "titleView" ></ TextBox >
                < TextBlock > Производитель </ TextBlock >
                < ComboBox Name= "companyView" >
                    < ComboBox.ItemTemplate >
                        < DataTemplate >
                            < TextBlock Text= "{Binding Path=Title}" />
                        </ DataTemplate >
                    </ ComboBox.ItemTemplate >
                </ ComboBox >
                < TextBlock > Цена </ TextBlock >
                < TextBox Name = "priceView" ></ TextBox >
                < TextBlock Name= "errorBox" />

                < StackPanel x:Name= "saveornotsave" VerticalAlignment= "Bottom" Visibility= "Hidden" >
                    < TextBlock Name= "saveQuestion" HorizontalAlignment= "Center" Text= "Хотите сохранить изменения?" />
                    < WrapPanel HorizontalAlignment= "Center" >
                        < Button Name= "yesButton"  MinWidth= "30" MaxWidth= "50" Click= "yesButton_Click" > Да </ Button >
                        < Button Name= "noButton" MinWidth= "30" MaxWidth= "50" Click= "noButton_Click" > Нет </ Button >
                    </ WrapPanel >
                </ StackPanel >

            </ StackPanel >
        </ GroupBox >

        < StackPanel Grid.Row= "1" Grid.Column= "0" Orientation= "Horizontal" >


            < Button x:Name= "editButtonView" Click= "EditButton_Click" Background= "Transparent"
                    Grid.Row= "1" MinWidth= "50" MaxWidth= "70" Margin= "10" BorderThickness= "0" >
                < Image Source= "/Image/edit.png" />
            </ Button >

            < Button x:Name= "deleteButtonView" Click= "EraseButton_Click" Background= "Transparent"
                    Grid.Row= "1" MinWidth= "50" Margin= "10" BorderThickness= "0" >
                < Image Source= "/Image/minus.png" />
            </ Button >

        </ StackPanel >

        < StackPanel Grid.Row= "1" Grid.Column= "1" Orientation= "Horizontal" >

            < Button x:Name= "saveEditButtonView" Click= "SaveEditButton_Click" MinWidth= "50" MaxWidth= "100" Margin= "10"
                    Grid.Row= "1" Background= "Transparent" BorderThickness= "0" >
                < Image Source= "/Image/save.png" />
            </ Button >

            < Button x:Name= "cancelEditButtonView" Click= "CancelEditButton_Click" MinWidth= "50" MaxWidth= "100" Margin= "10"
                    Grid.Row= "1" Background= "Transparent" BorderThickness= "0" >
                < Image Source= "/Image/cancel.png" />
            </ Button >
        </ StackPanel >*/
    }
}
