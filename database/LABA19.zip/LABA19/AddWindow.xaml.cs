﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LABA19
{
    /// <summary>
    /// Логика взаимодействия для AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public AddWindow()
        {
            InitializeComponent();
        }

        private void addbutton_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(titleView.Text) && companyView.SelectedIndex != -1 && !String.IsNullOrWhiteSpace(priceView.Text) && IsNum(priceView.Text) && Convert.ToDecimal(priceView.Text) > 0)
            {
                DatabaseControl.AddPhone(new Phone
                {
                    Title = titleView.Text,
                    CompanyId = (companyView.SelectedItem as Company).Id,
                    Price = Convert.ToDecimal(priceView.Text)
                });
                mainDataGridView.ItemsSource = null;
                mainListBox.ItemsSource = DatabaseControl.GetPhonesList();
                titleView.Text = String.Empty;
                companyView.Text = String.Empty;
                priceView.Text = String.Empty;
                errorBox.Text = String.Empty;
                EndEditing();
            }
            else
            {
                errorBox.Text = "Заполните данные корректно";
            }
        }

        private bool IsNum(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsDigit(c)) return false;
            }
            return true;
        }
    }
}
