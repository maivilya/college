﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LABA19
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        Phone updatedPhone;
        public EditWindow(Phone phone)
        {
            InitializeComponent();
            updatedPhone = phone;
            companyView.ItemsSource = null;
            companyView.ItemsSource = DatabaseControl.GetCompanyList();
            titleView.Text = phone.Title;
            companyView.SelectedValue = phone.CompanyEntity.Id;
            priceView.Text = phone.Price.ToString();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(titleView.Text) && companyView.SelectedIndex != -1 && !String.IsNullOrWhiteSpace(priceView.Text) && IsNum(priceView.Text) && Convert.ToDecimal(priceView.Text) > 0)
            {
                updatedPhone.Title = titleView.Text;
                updatedPhone.CompanyId = (int)companyView.SelectedValue;
                updatedPhone.Price = Convert.ToDecimal(priceView.Text);
                DatabaseControl.UpdatePhone(updatedPhone);

                (this.Owner as MainWindow).mainDataGridView.ItemsSource = null;
                (this.Owner as MainWindow).mainDataGridView.ItemsSource = DatabaseControl.GetPhonesList();
                EndEditing();
                this.Close();
            }
            else
            {
                errorBox.Text = "Заполните данные корректно";
            }
        }

        private void EndEditing()
        {
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;
            errorBox.Text = String.Empty;
            this.Owner.IsEnabled = true;
        }

        private bool IsNum(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsDigit(c)) return false;
            }
            return true;
        }
    }
}
