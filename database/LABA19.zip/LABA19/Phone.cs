﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABA19
{
    public class Phone
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int CompanyId { get; set; }
        public Decimal Price { get; set; }
        public Company CompanyEntity { get; set; }
    }
}
