﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using static bd_lab19.MainWindow;
using System.IO.Enumeration;

namespace bd_lab19
{
    /// <summary>
    /// Логика взаимодействия для editWindow.xaml
    /// </summary>
    public partial class editWindow : Window
    {
        private const string _imageSource =
            "S:\\313\\Images\\";
        public OpenFileDialog _img;
        private Phone _tempPhone;
        public editWindow(Phone phone)
        {
            InitializeComponent();
            _tempPhone = phone;
            companyView.ItemsSource = DatabaseControl.GetCompanies();
            titleView.Text = phone.Title;
            companyView.SelectedValue = phone.CompanyEntity.Id;
            priceView.Text = phone.Price.ToString();
            definitionView.Text = phone.Definition.ToString();
            SelectedText.Text = phone.Image;
        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            bool x1 = string.IsNullOrWhiteSpace(titleView.Text);
            if (x1 == true)
            {
                MessageBox.Show("Нельзя изменить на пустое значения!", "", MessageBoxButton.OK);
            }
            else if (titleView.Text != string.Empty && x1 != true)
            {
                decimal price;
                if (decimal.TryParse(priceView.Text, out price) && (companyView.SelectedItem as Company != null))
                {
                    if (price < 0)
                    {
                        MessageBox.Show("Нельзя изменить на отрицательное значения!", "", MessageBoxButton.OK);
                    }
                    else
                    {
                        _tempPhone.Title = titleView.Text;
                        _tempPhone.CompanyId = (int)companyView.SelectedValue;
                        _tempPhone.Price = Convert.ToDecimal(priceView.Text);
                        _tempPhone.Definition = definitionView.Text;
                        if (_img != null)
                        {
                            _tempPhone.Image = System.IO.Path.Combine(_imageSource, _img.SafeFileName);
                            File.Copy(_img.FileName, _tempPhone.Image, true);
                        }
                        DatabaseControl.UpdatePhone(_tempPhone);
                        (this.Owner as MainWindow).RefreshTable();
                        this.Close();
                    }
                }
            }
        }
        private void SelectImageButton_Click(object sender, RoutedEventArgs e) 
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Images (*.jpg, *.png)|*.jpg;*.png;*.JPG;*.PNG";
            if (openFileDialog.ShowDialog() == true)
            {
                _img = openFileDialog;
                if (_img != null && _img.FileName != null)
                {
                    SelectedText.Text = _img.FileName;
                }
            }
        }
    }
}