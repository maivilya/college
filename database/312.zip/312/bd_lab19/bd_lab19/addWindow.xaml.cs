﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using static bd_lab19.MainWindow;

namespace bd_lab19
{
    /// <summary>
    /// Логика взаимодействия для addWindow.xaml
    /// </summary>
    public partial class addWindow : Window
    {
        private const string _imageSource =
            "S:\\313\\Images\\";
        private OpenFileDialog _img;
        public addWindow()
        {
            InitializeComponent();
            companyView.ItemsSource = DatabaseControl.GetCompanies();

        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            bool x1 = string.IsNullOrWhiteSpace(titleView.Text);
            if (x1 == true)
            {
                MessageBox.Show("Нельзя добавить пустые поля!", "", MessageBoxButton.OK);
            }
            else if (titleView.Text != string.Empty && x1 != true)
            {
                decimal price;
                if (decimal.TryParse(priceView.Text, out price))
                {
                    if (price < 0)
                    {
                        MessageBox.Show("Нельзя добавить отрицательные значения!", "", MessageBoxButton.OK);
                    }
                    else if (companyView.SelectedItem as Company == null) 
                    {
                        MessageBox.Show("Выберите компанию!", "", MessageBoxButton.OK);
                    }
                    else
                    {
                        if (!Directory.Exists(_imageSource))
                        {
                            Directory.CreateDirectory(_imageSource);
                        }
                        else
                        {
                            if (_img == null) 
                            {
                                string imageurl = "S:\\313\\Image\\image.png";
                                DatabaseControl.AddPhone(new Phone
                                {
                                    Title = titleView.Text,
                                    CompanyId = (int)companyView.SelectedValue,
                                    Price = Convert.ToDecimal(priceView.Text),
                                    Image = imageurl,
                                    Definition = definitionView.Text,
                                });
                                (this.Owner as MainWindow).RefreshTable();
                                this.Close();
                            }
                            else if (_img != null)
                            {
                                string filePath = System.IO.Path.Combine(_imageSource, _img.SafeFileName);
                                File.Copy(_img.FileName, filePath, true);
                                DatabaseControl.AddPhone(new Phone
                                {
                                    Title = titleView.Text,
                                    CompanyId = (int)companyView.SelectedValue,
                                    Price = Convert.ToDecimal(priceView.Text),
                                    Image = filePath,
                                    Definition = definitionView.Text,
                                });
                                (this.Owner as MainWindow).RefreshTable();
                                this.Close();
                            }
                            
                        }
                    }
                }
            }
        }
        private void SelectImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Images (*.jpg, *.png)|*.jpg;*.png;*.JPG;*.PNG";
            if (openFileDialog.ShowDialog() == true)
            {
                _img = openFileDialog;
                if (_img != null && _img.FileName != null)
                {
                    SelectedText.Text = _img.FileName;
                }
            }
        }
    }
}
