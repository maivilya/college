﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace bd_lab19
{
    public  static class FrameContextcs
    {
        public static Frame MainWindowFrame { get; set; }
    }
}
