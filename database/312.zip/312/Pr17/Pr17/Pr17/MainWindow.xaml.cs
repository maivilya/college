﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text.Json;

namespace Pr17
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadJson();
            listToDo.ItemsSource = toDoList;
            EndToDo();
        }
        public static List<ToDo> toDoList = new List<ToDo>();
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (listToDo != null)
            {
                MessageBoxResult potvdelete = MessageBox.Show("Вы уверены, что хотите удалить дело?", "Удаление дела", MessageBoxButton.YesNo);
                if (potvdelete == MessageBoxResult.Yes)
                {
                    toDoList.Remove((sender as Button).DataContext as ToDo);
                    listToDo.ItemsSource = null;
                    listToDo.ItemsSource = toDoList;
                    EndToDo();
                }
            }
        }
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            ToDo toDoDo = (sender as CheckBox).DataContext as ToDo;
            if (toDoDo.Doing != true || toDoDo != null)
            {
                toDoDo.Doing = true;
                EndToDo();
            }
        }
        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            ToDo toDoDo = (sender as CheckBox).DataContext as ToDo;
            if (toDoDo.Doing != true || toDoDo != null)
            {
                toDoDo.Doing = false;
                EndToDo();
            }
        }
        public void EndToDo()
        {
            progressBarView.Minimum = 0;
            int complet = 0;
            if (toDoList.Count > 0)
            {
                int totalTask = toDoList.Count;
                progressBarView.Maximum = totalTask;

                foreach (ToDo i in toDoList)
                {
                    if (i.Doing)
                    {
                        complet++;
                    }
                }
                progressBarView.Value = complet;
                textProgressBar.Text = $"{complet}/{totalTask}";
            }
            else
            {
                progressBarView.Value = complet;
                textProgressBar.Text = "0/0";
            }
        }
        private void OpenAddWindow_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            AddWindow addWindow = new AddWindow();
            addWindow.Owner = this;
            addWindow.Show();
            EndToDo();
        }
        private void DeleteValue_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (listToDo.SelectedItem != null)
            {
                MessageBoxResult potvdelete = MessageBox.Show("Вы уверены, что хотите удалить дело?", "Удаление дела", MessageBoxButton.YesNo);
                if (potvdelete == MessageBoxResult.Yes)
                {
                    toDoList.Remove(listToDo.SelectedItem as ToDo);
                    listToDo.ItemsSource = null;
                    listToDo.ItemsSource = toDoList;
                    EndToDo();
                }
            }
        }
        private void SaveList_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (toDoList.Count == 0)
            {
                MessageBox.Show("В списке нет дел", "", MessageBoxButton.OK);
                return;
            }
            else
            {
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.Filter = "Text file (*.txt)|*.txt|JSON file (*.json)|*.json ";
                saveFile.Title = "Сохранение список дел";
                saveFile.FileName = "saved_list.txt";
                saveFile.OverwritePrompt = true;
                if (saveFile.ShowDialog() == true)
                {
                    if (saveFile.FilterIndex==1)
                    {
                        SaveTXT(saveFile.FileName);
                    }    
                    else
                    {
                        SaveJson();
                    }
                }
            }
        }
        private void SaveTXT(string txtSave)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (ToDo listItem in toDoList)
            {
                if (listItem.Doing == true)
                {
                    stringBuilder.AppendLine($"{"✓ " + listItem.NameWork}\n");
                    stringBuilder.AppendLine($"{listItem.DescripWork}\n");
                    stringBuilder.AppendLine($"{listItem.DateWork.ToString("dd.MM.yyyy")}\n");
                }
                else
                {
                    stringBuilder.AppendLine($"{listItem.NameWork}\n");
                    stringBuilder.AppendLine($"{listItem.DescripWork}\n");
                    stringBuilder.AppendLine($"{listItem.DateWork.ToString("dd.MM.yyyy")}\n");
                }
            }
            File.WriteAllText(txtSave, stringBuilder.ToString());
            Close();
        }
        private void SaveJson()
        {
            string directory = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Files", "saved_list.json");
            string json = JsonSerializer.Serialize(toDoList);
            if (Directory.Exists(System.IO.Path.GetDirectoryName(directory)))
            {
                File.WriteAllText(directory, json);
            }
            else
            {
                Directory.CreateDirectory(directory);
            }
        }
        private void LoadJson() 
        {
            string directory = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Files", "saved_list.json");
            string json = File.ReadAllText(directory);
            toDoList = JsonSerializer.Deserialize<List<ToDo>>(json);
        } 
    }
}
