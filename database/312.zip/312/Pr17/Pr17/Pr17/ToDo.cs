﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr17
{
    public class ToDo
    {
        private string nameWork;
        private DateTime dateWork;
        private string descripWork;
        private bool doing;
        public ToDo(string nameWork, DateTime dateWork, string descripWork, bool doing)
        {
            this.nameWork = nameWork;
            this.dateWork = dateWork;
            this.descripWork = descripWork;
            Doing = doing;
        }
        public string NameWork
        {
            get { return nameWork; }
            set { nameWork = value; }
        }
        public DateTime DateWork
        {
            get { return dateWork; }
            set { dateWork = value; }
        }
        public string DescripWork
        {
            get { return descripWork; }
            set { descripWork = value; }
        }
        public bool Doing
        {
            get { return doing; }
            set { doing = value; }
        }
    }
}
