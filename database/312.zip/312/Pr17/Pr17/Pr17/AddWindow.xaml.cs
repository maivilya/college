﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pr17
{
    /// <summary>
    /// Логика взаимодействия для AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public AddWindow()
        {
            InitializeComponent();
            descriptionToDo.Text = "Описания нет";
            dateToDo.SelectedDate = DateTime.Now;
        }
        public static RoutedCommand AddNewList = new RoutedCommand();
        private void OpenNewList_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MainWindow.toDoList.Add(new ToDo(titleToDo.Text, Convert.ToDateTime(dateToDo.SelectedDate), descriptionToDo.Text, false));
            (this.Owner as MainWindow).listToDo.ItemsSource = null;
            (this.Owner as MainWindow).listToDo.ItemsSource = MainWindow.toDoList;
            (this.Owner as MainWindow).EndToDo();
            this.Close();
        }
    }
}
