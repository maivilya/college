﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABA15
{
    public static class DatabaseControl
    {
        /// <summary>
        /// Метод получения списка всех телефонов из базы данных
        /// </summary>
        /// <returns>Список(List) телефонов</returns>
        public static List<Phone> GetPhonesList()
        {
            using (DbAppContext context = new DbAppContext())
            {
                return context.Phone.Include(p => p.CompanyEntity).ToList();
            }
        }

        /// <summary>
        /// Метод получения списка всех компаний из базы данных
        /// </summary>
        /// <returns>Спиисок(List) компаний</returns>
        public static List<Company> GetCompanyList()
        {
            using (DbAppContext context = new DbAppContext())
            {
                return context.Company.Include(c => c.PhonesEntity).ToList();
            }
        }

        /// <summary>
        /// Метод добавления телефона в базу данных и коллекцию телефонов
        /// </summary>
        /// <param name="phone">Новый телефон, который нужно добавить в базу данных</param>
        public static void AddPhone(Phone phone)
        {
            using (DbAppContext context = new DbAppContext())
            {
                context.Phone.Add(phone);
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Метод обновления телефона в базе данных и коллекции телефонов
        /// </summary>
        /// <param name="phone">Новая информация о телефоне в виде нового экземпляра</param>
        public static void UpdatePhone(Phone phone)
        {
            using(DbAppContext context = new DbAppContext()) 
            {
                Phone updatedPhone = context.Phone.FirstOrDefault(p => p.Id == phone.Id);
                if (updatedPhone != null)
                {
                    updatedPhone.Title = phone.Title;
                    updatedPhone.Price = phone.Price;
                    updatedPhone.CompanyId = phone.CompanyId;
                    context.SaveChanges();
                }
            }
        }

        /// <summary>
        /// Метод удаления телефона из базы данных и коллекции телефонов
        /// </summary>
        /// <param name="phone">Телефон, который нужно удалить</param>
        public static void DeletePhone(Phone phone)
        {
            using (DbAppContext context = new DbAppContext())
            {
                context.Phone.Remove(phone);
                context.SaveChanges();
            }
        }
    }
}
