﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LABA15
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = DatabaseControl.GetCompanyList();
            companyView.ItemsSource = null;
            companyView.ItemsSource = DatabaseControl.GetCompanyList();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            DatabaseControl.AddPhone(new Phone
            {
                Title = titleView.Text,
                CompanyId = (companyView.SelectedItem as Company).Id,
                Price = Convert.ToDecimal(priceView.Text)
            });
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = DatabaseControl.GetPhonesList();
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;
        }

        private void SaveEditButton_Click(object sender, RoutedEventArgs e)
        {
            Phone tempPhone = mainListBox.SelectedItem as Phone;
            if (tempPhone != null)
            {
                tempPhone.Title = titleView.Text;
                tempPhone.CompanyId = (companyView.SelectedItem as Company).Id;
                tempPhone.Price = Convert.ToDecimal(priceView.Text);

                mainListBox.ItemsSource = null;
                mainListBox.ItemsSource = DatabaseControl.GetPhonesList();
                errorBox.Text = String.Empty;
                EndEditing();
            }
            else
            {
                errorBox.Text = "Заполните данные корректно";
            }

        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            Phone tempPhone = mainListBox.SelectedItem as Phone;
            if (tempPhone != null)
            {
                titleView.Text = tempPhone.Title;
                companyView.SelectedIndex = tempPhone.CompanyId - 1;
                priceView.Text = tempPhone.Price.ToString();

                mainListBox.IsEnabled = false;
                addButtonView.IsEnabled = false;
                editButtonView.IsEnabled = false;
                deleteButtonView.IsEnabled = false;

                saveEditButtonView.Visibility = Visibility.Visible;
                cancelEditButtonView.Visibility = Visibility.Visible;
            }
        }

        private void EraseButton_Click(object sender, RoutedEventArgs e)
        {
            mainListBox.IsEnabled = false;
            addButtonView.IsEnabled = false;
            editButtonView.IsEnabled = false;
            deleteButtonView.IsEnabled = false;
            saveornotsave.Visibility = Visibility.Visible;
        }

        private void CancelEditButton_Click(object sender, RoutedEventArgs e)
        {
            EndEditing();
        }

        private void EndEditing()
        {
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;

            mainListBox.IsEnabled = true;
            addButtonView.IsEnabled = true;
            editButtonView.IsEnabled = true;
            deleteButtonView.IsEnabled = true;

            saveEditButtonView.Visibility = Visibility.Hidden;
            cancelEditButtonView.Visibility = Visibility.Hidden;
        }

        private void yesButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            DatabaseControl.DeletePhone(mainListBox.SelectedItem as Phone);
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = DatabaseControl.GetPhonesList();

            EndEditing();
        }

        private void noButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            EndEditing();
        }

        private static bool IsNullOrWhiteSpace(String value)
        {
            if (value == null) return true;

            for (int i = 0; i < value.Length; i++)
            {
                if (!Char.IsWhiteSpace(value[i])) return false;
            }

            return true;
        }
    }

}
