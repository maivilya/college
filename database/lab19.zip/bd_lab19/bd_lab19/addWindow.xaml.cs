﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static bd_lab19.MainWindow;

namespace bd_lab19
{
    /// <summary>
    /// Логика взаимодействия для addWindow.xaml
    /// </summary>
    public partial class addWindow : Window
    {
        public addWindow()
        {
            InitializeComponent();
            companyView.ItemsSource = DatabaseControl.GetCompanies();
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            bool x1 = string.IsNullOrWhiteSpace(titleView.Text);
            if (x1 == true)
            {
                MessageBox.Show("Нельзя добавить пустые поля!", "", MessageBoxButton.OK);
            }
            else if (titleView.Text != string.Empty && x1 != true)
            {
                decimal price;
                if (decimal.TryParse(priceView.Text, out price) && (companyView.SelectedItem as Company != null))
                {
                    if (price < 0) 
                    {
                        MessageBox.Show("НЕЛЬЗЯ ДОБАВЛЯТЬ ОТРИЦАТЕЛЬНЫЕ ЗНАЧЕНИЕ!", "", MessageBoxButton.OK);
                    }
                    else 
                    {
                        DatabaseControl.AddPhone(new Phone
                        {

                            Title = titleView.Text,
                            CompanyId = (int)companyView.SelectedValue,
                            Price = Convert.ToDecimal(priceView.Text)
                        });
                        (this.Owner as MainWindow).RefreshTable();
                        this.Close();
                    }
                }
            } 
        }

    }
}
