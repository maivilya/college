﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bd_lab19
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            mainDataGridView.ItemsSource = DatabaseControl.GetPhonesForView();
        }
        public Phone tempPhone;
        public class DbAppContext : DbContext
        {
            public DbSet<Phone> Phone { get; set; }
            public DbSet<Company> Company { get; set; }
            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                optionsBuilder.UseNpgsql(
                    "Host=localhost;Username=postgres;Password=root;Database=PhonesBd");
            }
            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                modelBuilder.Entity<Phone>().HasOne(p => p.CompanyEntity).WithMany(p => p.PhoneEntities);
            }
        }
        public static class DatabaseControl
        {
            public static List<Phone> GetPhonesForView()
            {
                using (DbAppContext ctx = new DbAppContext())
                {
                    return ctx.Phone.Include(p => p.CompanyEntity).ToList();
                }
            }
            public static void AddPhone(Phone phone)
            {
                using (DbAppContext ctx = new DbAppContext())
                {
                    ctx.Phone.Add(phone);
                    ctx.SaveChanges();
                }
            }
            public static void UpdatePhone(Phone phone)
            {
                using (DbAppContext ctx = new DbAppContext())
                {
                    Phone _phone = ctx.Phone.FirstOrDefault(p => p.Id == phone.Id);

                    _phone.Title = phone.Title;
                    _phone.Price = phone.Price;
                    _phone.CompanyId = phone.CompanyId;
                    ctx.SaveChanges();
                }
            }
            public static void DeletePhone(int phoneid)
            {
                using (DbAppContext ctx = new DbAppContext())
                {
                    Phone phoneDelete = ctx.Phone.FirstOrDefault(p => p.Id == phoneid);
                    if (phoneDelete != null)
                    {
                        ctx.Phone.Remove(phoneDelete);
                        ctx.SaveChanges();
                    }
                }
            }
            public static List<Company> GetCompanies()
            {
                using (DbAppContext ctx = new DbAppContext())
                {
                    return ctx.Company.ToList();
                }
            }
        }
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            addWindow win = new addWindow();
            win.Owner = this;
            win.ShowDialog();
        }
        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            Phone p = mainDataGridView.SelectedItem as Phone;
            if (p != null) 
            {
                editWindow win = new editWindow(p);
                win.Owner = this;
                win.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }
        public void RefreshTable()
        {
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetPhonesForView();
        }

        private void EraseButton_Click(object sender, RoutedEventArgs e)
        {
            if (mainDataGridView.SelectedItem != null)
            {
                MessageBoxResult window = MessageBox.Show("Вы точно хотите удалить?", "DELETE", MessageBoxButton.YesNo);
                switch (window)
                {
                    case MessageBoxResult.Yes:
                        tempPhone = mainDataGridView.SelectedItem as Phone;
                        DatabaseControl.DeletePhone(tempPhone.Id);
                        mainDataGridView.ItemsSource = null;
                        mainDataGridView.ItemsSource = DatabaseControl.GetPhonesForView();
                        break;
                    case MessageBoxResult.No:
                        break;
                }
            }
            else
            {
                MessageBox.Show("Сначала выберите значение!", "", MessageBoxButton.OK);
            }
        }
    }
}
