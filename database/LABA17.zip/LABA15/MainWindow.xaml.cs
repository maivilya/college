﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LABA15
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Phone> phones;
        private Phone tempPhone;
        public MainWindow()
        {
            InitializeComponent();
            saveEditButtonView.Visibility = Visibility.Hidden;
            cancelEditButtonView.Visibility = Visibility.Hidden;
            phones = new List<Phone>
            {
                new Phone {Company= "Apple",Title = "IPhone 10", Price = 1_000_000},
                new Phone {Company="Apple", Title="IPhone 11", Price = 2_000_000},
                new Phone {Company="Apple", Title="IPhone 12", Price = 3_000_000},
            };
            mainListBox.ItemsSource = phones;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!IsNullOrWhiteSpace(companyView.Text) && !IsNullOrWhiteSpace(titleView.Text) && Convert.ToDecimal(priceView.Text) > 0)
            {
                phones.Add(new Phone
                {
                    Company = companyView.Text,
                    Title = titleView.Text,
                    Price = Convert.ToDecimal(priceView.Text),
                });

                mainListBox.ItemsSource = null;
                mainListBox.ItemsSource = phones;
                titleView.Text = String.Empty;
                companyView.Text = String.Empty;
                priceView.Text = String.Empty;
                errorBox.Text = String.Empty;
            } else
            {
                errorBox.Text = "Заполните данные корректно";
            }

        }

        private void EraseButton_Click(object sender, RoutedEventArgs e)
        {
            mainListBox.IsEnabled = false;
            addButtonView.IsEnabled = false;
            editButtonView.IsEnabled = false;
            deleteButtonView.IsEnabled = false;
            saveornotsave.Visibility = Visibility.Visible;
        }

        private static bool IsNullOrWhiteSpace(String value)
        {
            if (value == null) return true;

            for (int i = 0; i < value.Length; i++)
            {
                if (!Char.IsWhiteSpace(value[i])) return false;
            }

            return true;
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            tempPhone = mainListBox.SelectedItem as Phone;
            if (tempPhone != null)
            {
                titleView.Text   = tempPhone.Title;
                companyView.Text = tempPhone.Company;
                priceView.Text = tempPhone.Price.ToString();

                mainListBox.IsEnabled = false;
                addButtonView.IsEnabled = false;
                editButtonView.IsEnabled = false;
                deleteButtonView.IsEnabled = false;

                saveEditButtonView.Visibility = Visibility.Visible;
                cancelEditButtonView.Visibility = Visibility.Visible;
            }
        }

        private void CancelEditButton_Click(object sender, RoutedEventArgs e)
        {
            EndEditing();
        }

        private void SaveEditButton_Click(object sender, RoutedEventArgs e)
        {
            if (!IsNullOrWhiteSpace(companyView.Text) && !IsNullOrWhiteSpace(titleView.Text) && Convert.ToDecimal(priceView.Text) > 0)
            {
                tempPhone.Title = titleView.Text;
                tempPhone.Company = companyView.Text;
                tempPhone.Price = Convert.ToDecimal(priceView.Text);

                mainListBox.ItemsSource = null;
                mainListBox.ItemsSource = phones;
                errorBox.Text = String.Empty;
                EndEditing();
            } else
            {
                errorBox.Text = "Заполните данные корректно";
            }
                
        }

        private void EndEditing()
        {
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;

            mainListBox.IsEnabled = true;
            addButtonView.IsEnabled = true;
            editButtonView.IsEnabled = true;
            deleteButtonView.IsEnabled = true;

            saveEditButtonView.Visibility = Visibility.Hidden;
            cancelEditButtonView.Visibility = Visibility.Hidden;
        }

        private void yesButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            phones.Remove(mainListBox.SelectedItem as Phone);
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;

            EndEditing();
        }

        private void noButton_Click(object sender, RoutedEventArgs e)
        {
            saveornotsave.Visibility = Visibility.Hidden;
            EndEditing();
        }
    }

}
