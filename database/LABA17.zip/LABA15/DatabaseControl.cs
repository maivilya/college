﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABA15
{
    public static class DatabaseControl
    {
        public static List<Phone> GetEmployeesList()
        {
            using (DbAppContext context = new DbAppContext())
            {
                return context.Phone.ToList();
            }
        }
    }
}
